    const serviceKey = "H4H9n%2FFccEhwXx4Pho%2FQE90tdBvDebI%2BCYHAiPj7vcqyQavijgwKRVu%2BtfpKSy6cNWoAxcQBSEqwnvlWQaLyVw%3D%3D";

    module.exports = {
        serviceKey : serviceKey
    };