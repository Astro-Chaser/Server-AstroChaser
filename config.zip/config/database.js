const mysql = require('mysql2/promise');
const {logger} = require('./winston');

const pool = mysql.createPool({
    host: 'crong-db.cqvib9zjbbje.ap-northeast-2.rds.amazonaws.com',
    user: 'admin',
    port: '3306',
    password: 'crongdev1214',
    timezone: 'KST',
    database: 'ACweb'
});

module.exports = {
    pool: pool
};