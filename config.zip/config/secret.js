module.exports = {
    'ACCESSjwtsecret' :  '0sg9u0s9023y48hwefn9ep48athfwse4afp',
    'REFRESHjwtsecret' : 'a8fsd8as9ufhaw983f129nr81923ub149r91',
    'accessKeyId' : `AKIATCQHPMEMSMGJVYOK`,
    'secretAccessKey' : `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`,
};